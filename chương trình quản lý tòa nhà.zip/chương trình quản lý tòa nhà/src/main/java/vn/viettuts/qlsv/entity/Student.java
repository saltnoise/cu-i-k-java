package vn.viettuts.qlsv.entity;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "student")
@XmlAccessorType(XmlAccessType.FIELD)
public class Student implements Serializable {
    private static final long serialVersionUID = 1L;
    private int id;
    private String buildingname;
    private String apartmentname;
    private float dientich;
    private String tiennghi;
    private String dichvu;
    private int price;
    private String ownername;
    private String status;

    public Student() {
    }

    public Student(int id ,String buildingname, String apartmentname, float dientich, String tiennghi, String dichvu, int price, String ownername, String status) {
        this.id = id;
        this.buildingname = buildingname;
        this.apartmentname = apartmentname;
        this.dientich = dientich;
        this.tiennghi = tiennghi;
        this.dichvu = dichvu;
        this.price = price;
        this.ownername = ownername;
        this.status = status;
    }

    public String getBuildingname() {
        return buildingname;
    }

    public String getApartmentname() {
        return apartmentname;
    }

    public float getDientich() {
        return dientich;
    }

    public String getTiennghi() {
        return tiennghi;
    }

    public String getDichvu() {
        return dichvu;
    }

    public int getPrice() {
        return price;
    }

    public String getOwnername() {
        return ownername;
    }

    public String getStatus() {
        return status;
    }

    public void setBuildingname(String buildingname) {
        this.buildingname = buildingname;
    }

    public void setApartmentname(String apartmentname) {
        this.apartmentname = apartmentname;
    }

    public void setDientich(float dientich) {
        this.dientich = dientich;
    }

    public void setTiennghi(String tiennghi) {
        this.tiennghi = tiennghi;
    }

    public void setDichvu(String dichvu) {
        this.dichvu = dichvu;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setOwnername(String ownername) {
        this.ownername = ownername;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}

