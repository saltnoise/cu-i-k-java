package vn.viettuts.qlsv.view;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.WindowConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import vn.viettuts.qlsv.entity.Student;

public class StudentView extends JFrame implements ActionListener, ListSelectionListener {
    private static final long serialVersionUID = 1L;
    private JButton addStudentBtn;
    private JButton editStudentBtn;
    private JButton deleteStudentBtn;
    private JButton clearBtn;
    private JButton sortStudentNameBtn;
    private JScrollPane jScrollPaneStudentTable;
    private JScrollPane jScrollPaneTiennghi;
    private JScrollPane jScrollPaneDichvu;
    private JTable studentTable;
    
    private JLabel idLabel;
    private JLabel buildingnameLabel;
    private JLabel apartmentnameLabel;
    private JLabel dientichLabel;
    private JLabel tiennghiLabel;
    private JLabel dichvuLabel;
    private JLabel priceLabel;
    private JLabel ownernameLabel;
    private JLabel statusLabel;
    
    private JTextField idField;
    private JTextField buildingnameField;
    private JTextField apartmentnameField;
    private JTextField dientichField;
    private JTextField ownernameField;
    private JTextArea tiennghiTA;
    private JTextArea dichvuTA;
    private JTextField priceField;
    private JTextField statusField;
    
    // định nghĩa các cột của bảng student
    private String [] columnNames = new String [] {
            "ID", "Buildingname", "Apartmentname", "Dientich", "Tiennghi", "Dichvu", "Ownername", "Price", "Status"};
    // định nghĩa dữ liệu mặc định của bẳng student là rỗng
    private Object data = new Object [][] {};
    
    public StudentView() {
        initComponents();
    }

    private void initComponents() {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        // khởi tạo các phím chức năng
        addStudentBtn = new JButton("Add");
        editStudentBtn = new JButton("Edit");
        deleteStudentBtn = new JButton("Delete");
        clearBtn = new JButton("Clear");
        sortStudentNameBtn = new JButton("Sort By Name");
        // khởi tạo bảng student
        jScrollPaneStudentTable = new JScrollPane();
        studentTable = new JTable();
        
        // khởi tạo các label
        idLabel = new JLabel("Id");
        buildingnameLabel = new JLabel("Buildingname");
        apartmentnameLabel = new JLabel("Apartmentname");
        dientichLabel = new JLabel("Dientich");
        tiennghiLabel = new JLabel("Tiennghi");
        dichvuLabel = new JLabel("Dichvu");
        ownernameLabel = new JLabel("Ownername");
        priceLabel = new JLabel("Price");
        statusLabel = new JLabel("Status");
        
        // khởi tạo các trường nhập dữ liệu cho student
        idField = new JTextField(6);
        idField.setEditable(false);
        buildingnameField = new JTextField(15);
        apartmentnameField = new JTextField(15);
        dientichField = new JTextField(15);
        tiennghiTA = new JTextArea();
        tiennghiTA.setColumns(15);
        tiennghiTA.setRows(5);
        jScrollPaneTiennghi = new JScrollPane();
        jScrollPaneTiennghi.setViewportView(tiennghiTA);
        dichvuTA = new JTextArea();
        dichvuTA.setColumns(15);
        dichvuTA.setRows(5);
        jScrollPaneDichvu = new JScrollPane();
        jScrollPaneDichvu.setViewportView(dichvuTA);
        ownernameField = new JTextField(15);
        priceField = new JTextField(15);
        statusField = new JTextField(10);
        
        // cài đặt các cột và data cho bảng student
        studentTable.setModel(new DefaultTableModel((Object[][]) data, columnNames));
        jScrollPaneStudentTable.setViewportView(studentTable);
        jScrollPaneStudentTable.setPreferredSize(new Dimension (480, 300));
        
         // tạo spring layout
        SpringLayout layout = new SpringLayout();
        // tạo đối tượng panel để chứa các thành phần của màn hình quản lý Student
        JPanel panel = new JPanel();
        panel.setSize(800, 420);
        panel.setLayout(layout);
        panel.add(jScrollPaneStudentTable);
        
        panel.add(addStudentBtn);
        panel.add(editStudentBtn);
        panel.add(deleteStudentBtn);
        panel.add(clearBtn);
        panel.add(sortStudentNameBtn);
        
        panel.add(idLabel);
        panel.add(buildingnameLabel);
        panel.add(apartmentnameLabel);
        panel.add(buildingnameLabel);
        panel.add(dientichLabel);
        panel.add(dichvuLabel);
        panel.add(tiennghiLabel);
        panel.add(ownernameLabel);
        panel.add(priceLabel);
        panel.add(statusLabel);
        
        panel.add(idField);
        panel.add(buildingnameField);
        panel.add(apartmentnameField);
        panel.add(dientichField);
        panel.add(jScrollPaneTiennghi);
        panel.add(jScrollPaneDichvu);
        panel.add(ownernameField);
        panel.add(priceField);
        panel.add(statusField);
        
        // cài đặt vị trí các thành phần trên màn hình login
        layout.putConstraint(SpringLayout.WEST, idLabel, 10, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, idLabel, 10, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, buildingnameLabel, 10, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, buildingnameLabel, 40, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, apartmentnameLabel, 10, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, apartmentnameLabel, 70, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, dientichLabel, 10, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, dientichLabel, 100, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, tiennghiLabel, 10, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, tiennghiLabel, 130, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, dichvuLabel, 10, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, dichvuLabel, 160, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, ownernameLabel, 10, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, ownernameLabel, 190, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, priceLabel, 10, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, priceLabel, 220, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, statusLabel, 10, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, statusLabel, 250, SpringLayout.NORTH, panel);

        layout.putConstraint(SpringLayout.WEST, idField, 100, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, idField, 10, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, buildingnameField, 100, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, buildingnameField, 40, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, apartmentnameField, 100, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, apartmentnameField, 70, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, dientichField, 100, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, dientichField, 100, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, jScrollPaneTiennghi, 100, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, jScrollPaneTiennghi, 130, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, jScrollPaneDichvu, 100, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, jScrollPaneDichvu, 160, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, ownernameField, 100, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, ownernameField, 190, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, priceField, 100, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, priceField, 220, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, statusField, 100, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, statusField, 250, SpringLayout.NORTH, panel);

        layout.putConstraint(SpringLayout.WEST, jScrollPaneStudentTable, 300, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, jScrollPaneStudentTable, 10, SpringLayout.NORTH, panel);

        layout.putConstraint(SpringLayout.WEST, addStudentBtn, 20, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, addStudentBtn, 300, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, editStudentBtn, 60, SpringLayout.WEST, addStudentBtn);
        layout.putConstraint(SpringLayout.NORTH, editStudentBtn, 300, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, deleteStudentBtn, 60, SpringLayout.WEST, editStudentBtn);
        layout.putConstraint(SpringLayout.NORTH, deleteStudentBtn, 300, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, clearBtn, 80, SpringLayout.WEST, deleteStudentBtn);
        layout.putConstraint(SpringLayout.NORTH, clearBtn, 300, SpringLayout.NORTH, panel);
        layout.putConstraint(SpringLayout.WEST, sortStudentNameBtn, 300, SpringLayout.WEST, panel);
        layout.putConstraint(SpringLayout.NORTH, sortStudentNameBtn, 330, SpringLayout.NORTH, panel);

        
        this.add(panel);
        this.pack();
        this.setTitle("Student Information");
        this.setSize(800, 420);
        // disable Edit and Delete buttons
        editStudentBtn.setEnabled(false);
        deleteStudentBtn.setEnabled(false);
        // enable Add button
        addStudentBtn.setEnabled(true);
    }
    
    public void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }
    
    /**
     * hiển thị list student vào bảng studentTable
     * 
     * @param list
     */
    public void showListStudents(List<Student> list) {
        int size = list.size();
        // với bảng studentTable có 5 cột, 
        // khởi tạo mảng 2 chiều students, trong đó:
        // số hàng: là kích thước của list student 
        // số cột: là 5
        Object [][] students = new Object[size][5];
        for (int i = 0; i < size; i++) {
            students[i][0] = list.get(i).getId(); 
            students[i][1] = list.get(i).getBuildingname(); 
            students[i][2] = list.get(i).getApartmentname(); 
            students[i][3] = list.get(i).getDientich(); 
            students[i][4] = list.get(i).getTiennghi(); 
            students[i][5] = list.get(i).getDichvu(); 
            students[i][6] = list.get(i).getOwnername(); 
            students[i][7] = list.get(i).getPrice(); 
            students[i][8] = list.get(i).getStatus();

        }
        studentTable.setModel(new DefaultTableModel(students, columnNames));
    }
    
    /**
     * điền thông tin của hàng được chọn từ bảng student 
     * vào các trường tương ứng của student.
     */
    public void fillStudentFromSelectedRow() {
        // lấy chỉ số của hàng được chọn 
        int row = studentTable.getSelectedRow();
        if (row >= 0) {
            idField.setText(studentTable.getModel().getValueAt(row, 0).toString()); 
            buildingnameField.setText(studentTable.getModel().getValueAt(row, 1).toString()); 
            apartmentnameField.setText(studentTable.getModel().getValueAt(row, 2).toString()); 
            dientichField.setText(studentTable.getModel().getValueAt(row, 3).toString()); 
            jScrollPaneTiennghi.setViewportView(new JTextArea(studentTable.getModel().getValueAt(row, 4).toString())); 
            jScrollPaneDichvu.setViewportView(new JTextArea(studentTable.getModel().getValueAt(row, 5).toString())); 
            ownernameField.setText(studentTable.getModel().getValueAt(row, 6).toString()); 
            priceField.setText(studentTable.getModel().getValueAt(row, 7).toString()); 
            statusField.setText(studentTable.getModel().getValueAt(row, 8).toString()); 


            // enable Edit and Delete buttons
            editStudentBtn.setEnabled(true);
            deleteStudentBtn.setEnabled(true);
            // disable Add button
            addStudentBtn.setEnabled(false);
        }
    }

    /**
     * xóa thông tin student
     */
    public void clearStudentInfo() {
        idField.setText("");
        buildingnameField.setText("");
        apartmentnameField.setText("");
        dientichField.setText("");
        jScrollPaneTiennghi.setViewportView(new JTextArea("")); 
        jScrollPaneDichvu.setViewportView(new JTextArea("")); 
        ownernameField.setText("");
        priceField.setText("");
        statusField.setText("");

        // disable Edit and Delete buttons
        editStudentBtn.setEnabled(false);
        deleteStudentBtn.setEnabled(false);
        // enable Add button
        addStudentBtn.setEnabled(true);
    }
    
    /**
     * hiện thị thông tin student
     * 
     * @param student
     */
    public void showStudent(Student student) {
       idField.setText(String.valueOf(student.getId())); 
apartmentnameField.setText(student.getApartmentname()); 
dientichField.setText(String.valueOf(student.getDientich())); 
jScrollPaneTiennghi.setViewportView(new JTextArea(student.getTiennghi())); 
jScrollPaneDichvu.setViewportView(new JTextArea(student.getDichvu())); 
ownernameField.setText(student.getOwnername()); 
priceField.setText(String.valueOf(student.getPrice())); 
statusField.setText(student.getStatus()); 
        // enable Edit and Delete buttons
        editStudentBtn.setEnabled(true);
        deleteStudentBtn.setEnabled(true);
        // disable Add button
        addStudentBtn.setEnabled(false);
    }
    
    /**
     * lấy thông tin student
     * 
     * @return
     */
    public Student getStudentInfo() {
        // validate student
        if (!validateBuildingName() || !validateApartmentName() || !validateDienTich() || !validateTienNghi() || !validateDichVu() || !validatePrice() || !validateOwnerName() || !validateStatus()) {
            return null;
        }
        try {
            Student student = new Student();
            if (idField.getText() != null && !"".equals(idField.getText())) {
                student.setId(Integer.parseInt(idField.getText()));
            }
            student.setBuildingname(buildingnameField.getText().trim()); // Tên tòa nhà
            student.setApartmentname(apartmentnameField.getText().trim()); // Tên căn hộ
            student.setDientich(Float.parseFloat(dientichField.getText().trim())); // Diện tích
            student.setTiennghi(jScrollPaneTiennghi.getViewport().getView().toString().trim()); // Tiện nghi
            student.setDichvu(jScrollPaneDichvu.getViewport().getView().toString().trim()); // Dịch vụ
            student.setOwnername(ownernameField.getText().trim()); // Tên chủ sở hữu
            student.setPrice(Integer.parseInt(priceField.getText().trim())); // Giá
            student.setStatus(statusField.getText().trim()); // Trạng thái

            return student;
        } catch (Exception e) {
            showMessage(e.getMessage());
        }
        return null;
    }
    
    private boolean validateBuildingName() {
    String buildingName = buildingnameField.getText();
    if (buildingName == null || buildingName.trim().isEmpty()) {
        buildingnameField.requestFocus();
        showMessage("Tên tòa nhà không được trống.");
        return false;
    }
    return true;
}

private boolean validateApartmentName() {
    String apartmentName = apartmentnameField.getText();
    if (apartmentName == null || apartmentName.trim().isEmpty()) {
        apartmentnameField.requestFocus();
        showMessage("Tên căn hộ không được trống.");
        return false;
    }
    return true;
}

private boolean validateDienTich() {
    try {
        float dienTich = Float.parseFloat(dientichField.getText().trim());
        if (dienTich <= 0) {
            dientichField.requestFocus();
            showMessage("Diện tích không hợp lệ, diện tích phải lớn hơn 0.");
            return false;
        }
    } catch (NumberFormatException e) {
        dientichField.requestFocus();
        showMessage("Diện tích không hợp lệ!");
        return false;
    }
    return true;
}

private boolean validateTienNghi() {
    String tienNghi = tiennghiTA.getText();
    if (tienNghi == null || tienNghi.trim().isEmpty()) {
        tiennghiTA.requestFocus();
        showMessage("Tiện nghi không được trống.");
        return false;
    }
    return true;
}

private boolean validateDichVu() {
    String dichVu = dichvuTA.getText();
    if (dichVu == null || dichVu.trim().isEmpty()) {
        dichvuTA.requestFocus();
        showMessage("Dịch vụ không được trống.");
        return false;
    }
    return true;
}

private boolean validatePrice() {
    try {
        int price = Integer.parseInt(priceField.getText().trim());
        if (price < 0) {
            priceField.requestFocus();
            showMessage("Giá không hợp lệ, giá phải lớn hơn hoặc bằng 0.");
            return false;
        }
    } catch (NumberFormatException e) {
        priceField.requestFocus();
        showMessage("Giá không hợp lệ!");
        return false;
    }
    return true;
}

private boolean validateOwnerName() {
    String ownerName = ownernameField.getText();
    if (ownerName == null || ownerName.trim().isEmpty()) {
        ownernameField.requestFocus();
        showMessage("Tên chủ sở hữu không được trống.");
        return false;
    }
    return true;
}

private boolean validateStatus() {
    String status = statusField.getText();
    if (status == null || status.trim().isEmpty()) {
        statusField.requestFocus();
        showMessage("Trạng thái không được trống.");
        return false;
    }
    return true;
}
    
    public void actionPerformed(ActionEvent e) {
    }
    
    public void valueChanged(ListSelectionEvent e) {
    }
    
    public void addAddStudentListener(ActionListener listener) {
        addStudentBtn.addActionListener(listener);
    }
    
    public void addEdiStudentListener(ActionListener listener) {
        editStudentBtn.addActionListener(listener);
    }
    
    public void addDeleteStudentListener(ActionListener listener) {
        deleteStudentBtn.addActionListener(listener);
    }
    
    public void addClearListener(ActionListener listener) {
        clearBtn.addActionListener(listener);
    }
    
    
    public void addSortStudentNameListener(ActionListener listener) {
        sortStudentNameBtn.addActionListener(listener);
    }
    
    public void addListStudentSelectionListener(ListSelectionListener listener) {
        studentTable.getSelectionModel().addListSelectionListener(listener);
    }
}
